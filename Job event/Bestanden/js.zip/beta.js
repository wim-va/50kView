$(function(){
    var mainHoogte = $('main').height();
    var articleHoogte = $('article').height();
    
    $('article').css('top', mainHoogte);
    var snelheid = ((articleHoogte-mainHoogte)/mainHoogte + 1) * 10000;
   
    $('article').animate({top:mainHoogte-articleHoogte}, snelheid,'linear');
    $('.sinterklaas').click(function(){
        $('.sinterklaas').css('text-decoration', 'none');
        $('.sintmaarten').css('text-decoration', 'line-through');
    });
     $('.sintmaarten').click(function(){
        $('.sinterklaas').css('text-decoration', 'line-through');
        $('.sintmaarten').css('text-decoration', 'none');
    });
    $('#fomo').click(function(){
        var fomotekst = $('#fomo').attr('title');
        $('#dlg_fomo').text(fomotekst);
        $('#dlg_fomo').dialog({
           title:'FOMO' 
        });
    })

});
