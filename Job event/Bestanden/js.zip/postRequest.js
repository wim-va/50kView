window.onload= init

function init(){
	// document.getElementById('form').addEventListener('change', collectData);
	document.getElementById('send').addEventListener('click', validateForSend);	
}

function validateData(bedrijf, voornaam, naam, email, tel, aantal, extra, callBack)
	{
	var status = true;
	var msg = '';
	
	var pattern = /^[a-zA-Z ,.'-]+$/;
	if (!pattern.test(voornaam) || voornaam.length < 2)
		{
			status = false;
			msg += 'Een voornaam mag enkel letters bevatten en moet minstens 2 karakters bevatten<br />';
		}
	if (!pattern.test(naam) || naam.length < 2)
		{
			status = false;
			msg += 'Een naam mag enkel letters bevatten en moet minstens 2 karakters bevatten<br />';
		}
	if (bedrijf.length <= 0)
		{
			status = false;
			msg += 'Gelieve een bedrijfsnaam in te geven<br />';
		}
		
	pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	if(!pattern.test(email))
		{
			status = false;
			msg += 'Gelieve een correct emailadres in te geven<br />';
		}
		
	if (tel.length > 0)
		{
			var tel = tel.replace(/[^0-9]/g, "");
			if (tel.length < 9 || tel.length > 14)
				{
					status = false;
					msg += 'Een telefoonnummer hoort uit minimaal 9 en maximaal 14 cijfers te bestaan<br />';	
				}
		}
	else
		{
			tel = '000000000';	
		}
		
	pattern = /^[0-9]+$/;
	if (!pattern.test(aantal))
		{
			status = false;
			msg += 'Het aantal aanwezigen hoort een positief geheel getal te zijn<br />';
		}
	
	if (extra.length > 0)
		{
			extra = 'Geen extra info doorgegeven';	
		}
		
	callBack.innerHTML = msg;
	return status;
}

function collectData() {
	var bedrijf = document.getElementById("bedrijf").value;
	var voornaam = document.getElementById("voornaam").value;
	var naam = document.getElementById("naam").value;
	var email = document.getElementById("email").value;
	var tel = document.getElementById("tel").value;
	var aantal = document.getElementById("aantal").value;
	var extra = document.getElementById('extra').value;
	var callBack = document.getElementById('status');
	validateData(bedrijf, voornaam, naam, email, tel, aantal, extra, callBack)
}

function validateForSend()
	{
		var bedrijf = document.getElementById("bedrijf").value;
		var voornaam = document.getElementById("voornaam").value;
		var naam = document.getElementById("naam").value;
		var email = document.getElementById("email").value;
		var tel = document.getElementById("tel").value;
		var aantal = document.getElementById("aantal").value;
		var extra = document.getElementById('extra').value;
		var callBack = document.getElementById('status');
		if (validateData(bedrijf, voornaam, naam, email, tel, aantal, extra, callBack))
			{
				sendData(bedrijf, voornaam, naam, email, tel, aantal, extra, callBack);
			}
	}

function sendData(bedrijf, voornaam, naam, email, tel, aantal, extra, callBack)
	{
		$.post('add.php', {
			send: true,
			bedrijf: bedrijf, 
			voornaam: voornaam, 
			naam: naam,
			email: email, 
			tel: tel,
			extra: extra,
			aantal: aantal}, 
			function(data){
				var data = JSON.parse(data);
				if(data.success) //Hier nog aanpassen wat er precies moet gebeuren, bv groene en rode achtergrond
					{
						callBack.innerText = data.msg;
                                                document.getElementById("bedrijf").value= "";
                                                document.getElementById("naam").value= "";
                                                document.getElementById("voornaam").value= "";
                                                document.getElementById("email").value= "";
                                                document.getElementById("tel").value= "";
                                                document.getElementById("aantal").value= "";
                                                document.getElementById("extra").value= "";
					}
				else
					{
						callBack.innerText = data.msg;
					}
			});
			
	}
