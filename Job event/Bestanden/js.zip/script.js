$(function () {
    new WOW().init();
})




    // function isScrolledIntoView(elem) {
    //     var docViewTop = $(window).scrollTop();
    //     var docViewBottom = docViewTop + $(window).height();
    //     var elemTop = $(elem).offset().top;
    //     var elemBottom = elemTop - $(elem).height();
    //     return ((elemBottom >= docViewTop) && (elemTop <= docViewBottom) && (elemBottom <= docViewBottom) && (elemTop >= docViewTop));
    // }

    // $(window).scroll(function () {
    //     if (isScrolledIntoView($('#contact'))) {
    //         console.log("visibile");
    //     }
    // });




    // console.log($(this).parent().parent().css({visibility:"hidden"}));



    // let iScrollPos = 0;
    // $(window).scroll(function () {
    //     let iCurScrollPos = $(this).scrollTop();
    //     if (iCurScrollPos > iScrollPos) {
    //         console.log("Scrolling down");

    //     } else {
    //         console.log("Scrolling up");
    //     }
    //     iScrollPos = iCurScrollPos;

    // });