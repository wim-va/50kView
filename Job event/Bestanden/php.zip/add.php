<?php
	require 'cred.php';
	if (isset($_POST['send']))
		{
			//Binnenhalen van de data
			$bedrijf = filter_var(trim($_POST['bedrijf']), FILTER_SANITIZE_STRING, FILTER_FLAG_ENCODE_AMP);//& encoden naar &amp
			
			$naam = trim($_POST['naam']);
			$voornaam = trim($_POST['voornaam']);
			
			$email = trim($_POST['email']);
			
			$tel = trim($_POST['tel']);
			$tel = filter_var($tel, FILTER_SANITIZE_NUMBER_INT); //Zorgen dat de telefoonnummer enkel cijfers bevat en eventuele +/- tekens
			$tel = str_replace('+', 00, $tel); //plustekens omzetten naar dubbel 0
			$tel = str_replace('-', '', $tel); // mintekens verwijderen 
			
			$extra = trim($_POST['extra']);
			
			$aantal = trim($_POST['aantal']);
			
			//Data valideren		
			try{
				if(!filter_var($email, FILTER_VALIDATE_EMAIL))//Valideren dat het een geldig emailadres is
					{
						throw new Exception('Email adres niet geldig');
					}
				/*if (strlen($tel) < 9 or strlen($tel) > 14) //Correcte lengte checken, minstens 9 cijfers voor huistelefoon zonder landscode, max 14 voor mobiel met landcode lange notatie
					{
						throw new Exception('Telefoonnummer niet geldig');
					}*/
				/*if (!ctype_alpha($naam) or !ctype_alpha($voornaam)) //Controleren of de naam en voornaam alleen uit alfabetische karakters bestaan
					{
						throw new Exception('Naam bevat ongeldige karakters');
					}*/
				if (!ctype_digit($aantal)) //Controleren of aantal enkel uit cijfers bestaat
					{
						throw new Exception('Aantal moet een geheel absoluut getal zijn');	
					}
			}catch(Exception $e)
				{
					echo JSON_encode(array('success'=>false, 'msg'=>$e->getMessage()));
					break;
				};
			
			//Mysqli connecti aanroepen en statements voorbereiden
			$connection = new MySQLi(_HOST, _USER, _PASS, _DB);
			if(mysqli_connect_errno())
				{
					echo mysqli_connect_error();
					break;
				}
			else
				{
					$insert = $connection->prepare('INSERT INTO aanwezig (bedrijf, naam, voornaam, email, tel, aantal, extraInfo) VALUES(?, ?, ?, ?, ?, ?, ?)');
			
					//String escapen voor eventuele SQL injectie te voorkomen
					$mysql_bedrijf = mysqli_real_escape_string($connection, $bedrijf);
					$mysql_naam = mysqli_real_escape_string($connection, $naam);
					$mysql_voornaam = mysqli_real_escape_string($connection, $voornaam);
					$mysql_email = mysqli_real_escape_string($connection, $email);
					$mysql_tel = mysqli_real_escape_string($connection, $tel);
					$mysql_aantal = mysqli_real_escape_string($connection, $aantal);
					$mysql_extra = mysqli_real_escape_string($connection, $extra);
					//Prepared statemend binden
					$insert->bind_param("sssssss", $mysql_bedrijf, $mysql_naam, $mysql_voornaam, $mysql_email, $mysql_tel, $mysql_aantal, $mysql_extra);
					//Uitvoeren
					if($insert->execute())
						{
							echo JSON_encode(array('success'=>true, 'msg'=>'U bent ingeschreven'));	
						}
					else
						{
							echo JSON_encode(array('success'=>false, 'msg'=>'Fout bij verwerken gegevens'));
						}
					$insert->close();
					$connection->close();
				}
		}
?>
