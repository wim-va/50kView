<?php
	session_start();
	if (!empty($_GET['email']))
		{
			$_SESSION['email'] = $_GET['email'];
		}
	if (!empty($_GET['bedrijf']))
		{
			$_SESSION['bedrijf'] = $_GET['bedrijf'];	
		}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Jobhosting</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!--Stylesheet-->
    <link href="style.css" rel="stylesheet">
    <!--Font Awesome-->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!--Font Lato-->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
    <!-- Animate -->
    <link href="css/animate.min.css" rel="stylesheet">
</head>

<body>
    <div class="menu-wrapper">
       
        <div class="decoratie">
            <div class="lijntje-header"></div>
            <div class="bolletje-header"></div>
            <div class="lijntje-header2"></div>
            <div class="bolletje-header2"></div>
        </div>
    </div>
    <section id="contact">
        <div class="container-fluid">
            <div class="row">
                <div class="menu-wrapper">
                    <div class="header-save-the-date text-uppercase text-center">
                        <p>Save the date 21 februari</p>
                    </div>
                    <div class="decoratie">
                        <div class="lijntje-header"></div>
                        <div class="bolletje-header"></div>
                        <div class="lijntje-header2"></div>
                        <div class="bolletje-header2"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-11 col-md-offset-1">
                    <h1>Wij heten u alvast welkom in de Belpairestraat 39 te Berchem</h1>
                </div>
           </div>
            <!-- Formulier -->
                    <div class="row">
                        <form id="form">
                         <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <div id="status">
                                    <p>Velden met een sterretje (*) zijn verplicht</p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4 col-md-offset-1">
                                <label for="voornaam">Voornaam *</label>
                                <input type="text" class="form-control" id="voornaam" name="voornaam">
                            </div>
                            <div class="form-group col-md-4 col-md-offset-1">
                                <label for="naam">Naam *</label>
                                <input type="text" class="form-control" id="naam" name="naam">
                            </div>
                        </div>
                        <div class="row">    
                            <div class="form-group col-md-4  col-md-offset-1">
                                <label for="email">E-mail *</label>
                                <input type="email" class="form-control" id="email" name="email" <?php if (isset($_SESSION['email'])){echo 'value="'.$_SESSION['email'].'"';} ?>>
                            </div>
                            <div class="form-group col-md-4 col-md-offset-1">
                                <label for="bedrijf">Bedrijf *</label>
                                <input type="text" class="form-control" id="bedrijf" name="bedrijf" <?php if (isset($_SESSION['bedrijf'])){echo 'value="'.$_SESSION['bedrijf'].'"';} ?>>
                            </div>
                       </div>
                       <div class="row">
                            <div class="form-group col-md-4 col-md-offset-1">
                                <label for="tel">Telefoonnummer</label>
                                <input type="tel" class="form-control" id="tel" name="tel">
                            </div>
                            <div class="form-group col-md-4 col-md-offset-1">
                                <label for="aantal">Aantal deelnemers *</label>
                                <input type="text" class="form-control" id="aantal" name="aantal">
                            </div>
                       </div>
                       <div class="row">
                            <div class="form-group col-md-4 col-md-offset-1">
                                <textarea name="extra" id="extra" cols="40" rows="5" placeholder="extra info"></textarea>
                            </div>
                       </div>
                       <div class="row">
                            <div class="col-md-4 col-md-offset-1">
                                <input type="button" class="btn btn-success btn-lg" id="send" value="Ja, ik kom" />
                            </div>
                       </div>
                    </form>
                 </div>
                 <div class="row">
                    <div class="links col-md-offset-1">
            <div class="navigation navigationContact wow fadeIn" data-wow-delay="0.8s" id="lol">
                <ul>
                    <li><a href="index.php"><i class="fa fa-home" aria-hidden="true" id="btnHome"></i></a></li>
                    <li><a href="agenda.html"><i class="fa fa-clock-o" aria-hidden="true" id="btnAgenda"></i></a></li>
                    <li><a href="contact.php"><i class="fa fa-pencil" aria-hidden="true" id="btnContact"></i></a></li>
                </ul>
            </div>
        </div>
       </div>
       </div>
        </div>
       </div>
    </section>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/postRequest.js"></script>
</body>

</html>
