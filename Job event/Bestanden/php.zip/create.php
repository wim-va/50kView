<?php
	require 'cred.php';
	$query = "CREATE TABLE aanwezig
(
	bedrijf varchar(100),
    naam varchar(50),
    voornaam varchar(50),
    email varchar(30),
    tel int,
    aantal int,
    extraInfo text
)";
	$connection = mysqli_connect(_HOST, _USER, _PASS, _DB);
	if (!mysqli_connect_errno())
		{
			if(mysqli_query($connection, $query))
				{
					echo 'Table aangemaakt';	
				}
			else
				{
					echo mysqli_error($connection);
				}
			mysqli_close($connection);
		}
?>
