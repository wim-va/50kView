<?php
	define('_DB', 'jobhosting');
	define('_HOST', 'localhost');
	define('_USER', 'jobhoster');//jobhoster
	define('_PASS', 'pwd007,');//pwd007,
?>
