<?php
	session_start();
	if (!empty($_GET['email']))
		{
			$_SESSION['email'] = $_GET['email'];
		}
	if (!empty($_GET['bedrijf']))
		{
			$_SESSION['bedrijf'] = $_GET['bedrijf'];	
		}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Jobhosting</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!--Stylesheet-->
    <link href="style.css" rel="stylesheet">
    <!--Font Awesome-->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!--Font Lato-->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
    <!-- Animate -->
    <link href="css/animate.min.css" rel="stylesheet">
</head>

<body>

    <header id="home">
        <div class="container-fluid">
            <div class="row container">
                <div class="row">
                    <div class="col-sm-4 col-sm-offset-4 text-center hidden-md hidden-lg">
                         <p>Save the date 21 februari</p>
                    </div>
                </div>
                <div class="menu-wrapper">
                    <div class="header-save-the-date text-uppercase text-center hidden-sm hidden-xs">
                        <p>Save the date 21 februari</p>
                    </div>
                    <div class="decoratie">
                        <div class="lijntje-header"></div>
                        <div class="bolletje-header"></div>
                        <div class="lijntje-header2"></div>
                        <div class="bolletje-header2"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-1 col-md-offset-2">
                    <img src="img/logo.png" alt="Jobhosting logo" class="img-responsive wow fadeIn" data-wow-delay="0.2s">
                </div>
                <div class="col-md-6">
                    <h1 class="text-uppercase wow fadeIn" data-wow-delay="0.3s">Jobhosting</h1>
                </div>
                <div class="col-md-6 col-md-offset-3">
                    <h3 class="wow fadeIn" data-wow-delay="0.4s">Wat is jobhosting</h3>
                    <p class="intro wow fadeIn" data-wow-delay="0.5s">Op 21 november 2016 zijn wij gestart aan de opleiding JavaScript Front End Developer bij Beta vzw.
Met variërende niveaus van voorkennis gingen we de uitdaging aan om aan een razendsnel tempo omgeschoold te worden
tot Front End Developer.</p>
                    <p class="skills wow fadeIn" style="padding-bottom:10px;" data-wow-delay="0.6s">Op amper 3 maanden tijd hebben wij leren werken met JavaScript, HTML5, CSS3, Drupal, Bootstrap en jQuery.</p>
                    <p class="intro wow fadeIn" data-wow-delay="0.5s">Wij zijn elf gemotiveerde personen die op zoek zijn naar een bedrijf dat bereid is ons een stageplaats aan te bieden.
Om ons te leren kennen organiseren wij daarom op <strong>dinsdag 21 februari 2017</strong> in de Belpairestraat 39 te Berchem "JobHosting". 
Op dit event kan u met ons, aspirant Front End developers, een gesprek komen houden
waardoor we elkaar beter kunnen leren kennen en u onze
interesses kan ontdekken.
</p>
    
                </div>
            </div>

            <div class="row">
                <div class="links col-md-offset-3">
                    <div class="navigation navigationContact wow fadeIn" data-wow-delay="0.8s" id="lol">
                        <ul>
                            <li><a href="index.php"><i class="fa fa-home" aria-hidden="true" id="btnHome"></i></a></li>
                            <li><a href="agenda.html"><i class="fa fa-clock-o" aria-hidden="true" id="btnAgenda"></i></a></li>
                            <li><a href="contact.php"><i class="fa fa-pencil" aria-hidden="true" id="btnContact"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </header>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/script.js"></script>
</body>

</html>
