<?php
	require 'cred.php';
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Kijk 'ns aan..</title>
</head>
<body>
<?php
	//Mysqli connecti aanroepen en statements voorbereiden
	$connection = mysqli_connect(_HOST, _USER, _PASS, _DB);
	try{
		if(mysqli_connect_errno())
			{
				throw new Exception('Probleem in de server #1');	
			}
		$insert = $connection ->prepare("SELECT bedrijf, naam, voornaam, email, tel, aantal, extraInfo FROM aanwezig");
		if($insert->execute())
			{
				print('<table border="1" cellpadding="5"><thead><tr><th>Naam bedrijf</th><th>Naam contactpersoon</th><th>Emailadres</th><th>Telefoonnummer</th><th>Aantal aanwezigen</th><th>Extra</th></tr></thead><tbody>');
				$insert->bind_result($bedrijf, $naam, $voornaam, $email, $tel, $aantal,$extra);
				while($insert->fetch())
					{
						print('<tr><td>'.$bedrijf.'</td><td>'.$voornaam.' '.$naam.'</td><td>'.$email.'</td><td>'.$tel.'</td><td>'.$aantal.'</td><td>'. str_replace('\n', '<br>', $extra).'</td></tr>');
					}
				print('</tbody></table>');
				//Connecties sluiten indien succesvol
				$insert->close();
				$connection->close();
			}
		else
			{
				throw new Exception('Probleem in de server #2');	
			}
	}catch(Exception $c)
		{
			$insert->close();
			$connection->close();
			return JSON_encode(array('success'=>false, 'msg'=>$c->getMessage()));	
		}
?>
</body>
</html>
